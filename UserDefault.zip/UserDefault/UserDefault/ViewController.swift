//
//  ViewController.swift
//  UserDefault
//
//  Created by syed fazal abbas on 10/05/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtUserName: UITextField!
    @IBOutlet var txtGmail: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblGmail: UILabel!
    @IBOutlet var lblPassword: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let name = UserDefaults.standard.value(forKey: "UserName")
        if name  != nil {
            txtUserName.text = (UserDefaults.standard.value(forKey: "UserName") as! String)
            txtGmail.text =  (UserDefaults.standard.value(forKey: "Gmail") as! String)
            txtPassword.text  = (UserDefaults.standard.value(forKey: "Password") as! String)
            
        }
    }
    @IBAction func btnTappedSave(_ sender: UIButton) {
        let alertaction = UIAlertController(title: "Saving", message: "Are You want to save your dat", preferredStyle: .alert)
        let yesbutton = UIAlertAction(title: "Yes", style: .default) { action in
            UserDefaults.standard.set(self.txtUserName.text, forKey: "UserName")
            UserDefaults.standard.set(self.txtGmail.text, forKey: "Gmail")
            UserDefaults.standard.set(self.txtPassword.text,forKey: "Password")
        }
        let noButton = UIAlertAction(title: "No", style: .destructive) { action in
            print("Your Login Detail is Not Saved")
        }
        alertaction.addAction(yesbutton)
        alertaction.addAction(noButton)
        self.present(alertaction, animated: true)
    }
    
}

